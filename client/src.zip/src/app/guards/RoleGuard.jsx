import { useSelector } from "react-redux";
import { checkPermissions } from "./permissions.js";

/**
 * RoleGuard Component: Restricts complete page trees based on the active user role.
 */
export const RoleGuard = ({ children, allowedRoles, fallback }) => {
  const currentRole = useSelector((state) => state.auth.role);
  const hasAccess = checkPermissions(currentRole, allowedRoles);
  const visibleRole = currentRole ?? "GUEST";

  if (!hasAccess) {
    if (fallback) return <>{fallback}</>;
    
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4 p-8 text-center glass-pane rounded-2xl m-4 border border-red-500/10">
        <div className="w-16 h-16 rounded-full bg-red-950/45 border border-red-500/20 flex items-center justify-center mb-2">
          <svg className="w-8 h-8 text-red-500" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
          </svg>
        </div>
        <h2 className="text-2xl font-bold font-display text-white">Access Violation</h2>
        <p className="text-gray-400 font-sans max-w-sm">
          Your current security clearance level (<span className="text-brand-green font-semibold">{visibleRole}</span>) is insufficient to access this action console.
        </p>
      </div>
    );
  }

  return <>{children}</>;
};

/**
 * PermissionGate Component: Conditional inline rendering wrapper based on RBAC criteria.
 */
export const PermissionGate = ({ allowedRoles, children, fallback = null }) => {
  const currentRole = useSelector((state) => state.auth.role);
  const hasAccess = checkPermissions(currentRole, allowedRoles);

  return hasAccess ? <>{children}</> : <>{fallback}</>;
};
